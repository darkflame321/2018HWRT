package com.elasticcloudservice.predict;

public class PhyServer {
	public String name;
	public int allCPU;
	public int allMEM;
	
	
	public PhyServer(String name,int allCPU,int allMEM) {
		this.name=name;
		this.allCPU=allCPU;
		this.allMEM=allMEM;
	}

}
